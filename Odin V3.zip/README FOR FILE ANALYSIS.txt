Hey, not sure if the Discord Rich Precense falls under Rule.2 of file uploading,
but I'm gonna leave it there anyways if it's an issue tell me or feel free to remove it yourself.

Every file required to compile is in here, the DLL itself is called "Odin.dll" and in the root folder.

To compile just compile in release x64 that's it, should work fine.

You might need detours (from vcpkg) and the DX math SDK 2010 thing.

MAKE SURE TO ONLY INCLUDE THE DLL IN THE DOWNLOAD.

Thanks for taking time to analyse my shit I love y'all UC mods and analysers <3