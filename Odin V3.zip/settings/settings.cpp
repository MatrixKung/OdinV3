#pragma once

#include "settings.h"

c_config config_system;
