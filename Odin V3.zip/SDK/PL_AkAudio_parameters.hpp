#pragma once

// Paladins (5.6) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "PL_AkAudio_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AkAudio.AkAmbientSound.StopPlayback
struct AAkAmbientSound_StopPlayback_Params
{
};

// Function AkAudio.AkAmbientSound.StartPlayback
struct AAkAmbientSound_StartPlayback_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
