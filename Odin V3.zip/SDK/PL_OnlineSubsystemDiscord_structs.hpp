#pragma once

// Paladins (5.6) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x4)
#endif

#include "PL_Basic.hpp"
#include "PL_IpDrv_classes.hpp"
#include "PL_Core_classes.hpp"

namespace SDK
{
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
